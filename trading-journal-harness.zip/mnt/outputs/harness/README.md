# trading-journal · 3-AI Harness

기획(Planner) · 구현(Implementer) · 평가(Evaluator)를 **서로 다른 AI**에 맡기는 자동 작업 파이프라인.

## 구조
```
harness/
├─ schemas/        # spec / patch / eval JSON 스키마 (파이프라인의 헌법)
├─ prompts/        # 단계별 system prompt
├─ adapters/       # Anthropic / OpenAI / Google 통합 호출 레이어
├─ agents/         # (확장 여지)
├─ runner.js       # 오케스트레이터 (planner → implementer → test → evaluator → 재시도)
├─ config.yaml     # 단계별 모델 매핑·예산·가드레일
├─ .env.example
├─ sandbox/        # git worktree로 만들어둔 격리 작업공간
├─ evals/
│   ├─ tasks/      # 골든 태스크 (입력)
│   └─ rubrics/    # 루브릭 문서
└─ runs/           # 실행 로그(JSON) — 모델·토큰·비용·결과
```

## 셋업
```bash
cd harness
cp .env.example .env       # 키 채우기
npm install

# sandbox는 메인 코드 오염 방지용 격리 워크트리
cd ..
git worktree add harness/sandbox HEAD
cd harness/sandbox && npm install && cd ../..
```

## 실행
```bash
cd harness
node runner.js evals/tasks/feat-price-cache.json
```

성공 시 `runs/<timestamp>-feat-price-cache.json`에 전체 trace가 남습니다.
verdict가 `approve`면 sandbox에 있는 변경을 사람이 확인 후 메인으로 머지합니다.

## 단계별 모델 (config.yaml)
| 단계 | 기본값 | 이유 |
|------|--------|------|
| planner | claude-opus-4-6 | 한국어 요구사항 추출·맥락 파악 |
| implementer | gpt-5-codex | diff 생산성·정확도 |
| evaluator | gemini-2.5-pro | **다른 패밀리**로 교차검증 |

> 평가자는 반드시 구현자와 다른 회사의 모델로 둘 것. 같은 모델 자기평가는 점수 부풀려진다.

## 안전장치
- `forbiddenPaths`: `.env`, `auth.js`, `harness/` 수정 차단
- `maxFilesPerPatch`: 한 번에 너무 많은 파일 변경 차단
- `maxUsdPerRun`: 호출 비용 상한
- 모든 산출물은 schema 검증 통과해야 다음 단계로 넘어감
- sandbox 워크트리 격리 → 평가 통과 전에는 메인 코드 오염 0

## 다음 골든 태스크 후보
1. `feat-rls-policies` — Supabase RLS SQL + 마이그레이션
2. `feat-rr-column` — 트레이드 로그 RR 자동계산 컬럼
3. `feat-stocks-search` — SYMBOL_MAP 제거 + stocks.json 전체 검색
4. `feat-monthly-stats-chart` — 통계 탭 월별 승률 차트
5. `feat-ai-review-v0` — 트레이드 1건 → 3줄 한국어 회고
