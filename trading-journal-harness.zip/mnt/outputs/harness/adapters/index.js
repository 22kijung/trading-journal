// 통합 LLM 어댑터 — provider만 보고 분기. 모든 어댑터는 동일한 시그니처를 갖는다.
// call({ system, user, temperature, maxTokens }) -> { text, usage:{inputTokens,outputTokens,usd} }

import 'dotenv/config';

const PRICING = {
  // USD per 1M tokens (대략치, 주기적으로 갱신할 것)
  'claude-opus-4-6':   { in: 15,  out: 75 },
  'claude-sonnet-4-6': { in: 3,   out: 15 },
  'gpt-5-codex':       { in: 5,   out: 20 },
  'gemini-2.5-pro':    { in: 3.5, out: 10.5 },
};

function calcUsd(model, inTok, outTok) {
  const p = PRICING[model] || { in: 0, out: 0 };
  return (inTok * p.in + outTok * p.out) / 1_000_000;
}

async function callAnthropic({ model, system, user, temperature, maxTokens }) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      model, max_tokens: maxTokens, temperature, system,
      messages: [{ role: 'user', content: user }],
    }),
  });
  if (!res.ok) throw new Error(`anthropic ${res.status}: ${await res.text()}`);
  const j = await res.json();
  const text = j.content?.[0]?.text ?? '';
  const inTok = j.usage?.input_tokens ?? 0;
  const outTok = j.usage?.output_tokens ?? 0;
  return { text, usage: { inputTokens: inTok, outputTokens: outTok, usd: calcUsd(model, inTok, outTok) } };
}

async function callOpenAI({ model, system, user, temperature, maxTokens }) {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      model, temperature, max_tokens: maxTokens,
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: user },
      ],
    }),
  });
  if (!res.ok) throw new Error(`openai ${res.status}: ${await res.text()}`);
  const j = await res.json();
  const text = j.choices?.[0]?.message?.content ?? '';
  const inTok = j.usage?.prompt_tokens ?? 0;
  const outTok = j.usage?.completion_tokens ?? 0;
  return { text, usage: { inputTokens: inTok, outputTokens: outTok, usd: calcUsd(model, inTok, outTok) } };
}

async function callGoogle({ model, system, user, temperature, maxTokens }) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${process.env.GOOGLE_API_KEY}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: system }] },
      contents: [{ role: 'user', parts: [{ text: user }] }],
      generationConfig: { temperature, maxOutputTokens: maxTokens },
    }),
  });
  if (!res.ok) throw new Error(`google ${res.status}: ${await res.text()}`);
  const j = await res.json();
  const text = j.candidates?.[0]?.content?.parts?.[0]?.text ?? '';
  const inTok = j.usageMetadata?.promptTokenCount ?? 0;
  const outTok = j.usageMetadata?.candidatesTokenCount ?? 0;
  return { text, usage: { inputTokens: inTok, outputTokens: outTok, usd: calcUsd(model, inTok, outTok) } };
}

export async function callLLM(stageCfg, { system, user }) {
  const args = {
    model: stageCfg.model,
    system, user,
    temperature: stageCfg.temperature ?? 0.2,
    maxTokens:   stageCfg.maxTokens   ?? 4000,
  };
  switch (stageCfg.provider) {
    case 'anthropic': return callAnthropic(args);
    case 'openai':    return callOpenAI(args);
    case 'google':    return callGoogle(args);
    default: throw new Error(`unknown provider: ${stageCfg.provider}`);
  }
}
