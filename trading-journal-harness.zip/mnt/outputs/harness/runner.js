// 3-AI 하네스 오케스트레이터
// 사용법: node harness/runner.js evals/tasks/feat-price-cache.json
//
// 흐름: planner → implementer → (sandbox 적용 + npm test) → evaluator
//        approve 되면 종료, revise 면 hints 들고 재시도, reject 면 중단.

import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';
import YAML from 'yaml';
import Ajv from 'ajv';
import { callLLM } from './adapters/index.js';

const ROOT = path.dirname(new URL(import.meta.url).pathname);
const cfg  = YAML.parse(fs.readFileSync(path.join(ROOT, 'config.yaml'), 'utf8'));

const ajv = new Ajv({ allErrors: true, strict: false });
const validators = {
  spec:  ajv.compile(JSON.parse(fs.readFileSync(path.join(ROOT, 'schemas/spec.schema.json'), 'utf8'))),
  patch: ajv.compile(JSON.parse(fs.readFileSync(path.join(ROOT, 'schemas/patch.schema.json'), 'utf8'))),
  eval:  ajv.compile(JSON.parse(fs.readFileSync(path.join(ROOT, 'schemas/eval.schema.json'), 'utf8'))),
};

const prompts = {
  planner:     fs.readFileSync(path.join(ROOT, 'prompts/planner.system.md'),     'utf8'),
  implementer: fs.readFileSync(path.join(ROOT, 'prompts/implementer.system.md'), 'utf8'),
  evaluator:   fs.readFileSync(path.join(ROOT, 'prompts/evaluator.system.md'),   'utf8'),
};

function parseJSON(text, label) {
  // 모델이 가끔 코드펜스를 붙이는 경우 방어
  const cleaned = text.replace(/^```(?:json)?\s*|\s*```$/g, '').trim();
  try { return JSON.parse(cleaned); }
  catch (e) { throw new Error(`${label} JSON parse failed: ${e.message}\n--- raw ---\n${text.slice(0, 500)}`); }
}

function loadRepoContext(touchedFiles) {
  const ctx = {};
  for (const rel of touchedFiles) {
    const abs = path.resolve(ROOT, cfg.paths.repoRoot, rel);
    ctx[rel] = fs.existsSync(abs) ? fs.readFileSync(abs, 'utf8') : '(NEW FILE)';
  }
  return ctx;
}

function checkGuardrails(patch) {
  for (const f of patch.files) {
    for (const forb of cfg.guardrails.forbiddenPaths) {
      if (f.path === forb || f.path.startsWith(forb + '/')) {
        throw new Error(`guardrail violation: forbidden path ${f.path}`);
      }
    }
  }
  if (patch.files.length > cfg.guardrails.maxFilesPerPatch) {
    throw new Error(`guardrail violation: too many files (${patch.files.length})`);
  }
}

function applyToSandbox(patch) {
  const sandboxRoot = path.resolve(ROOT, cfg.paths.sandboxDir);
  // sandbox는 git worktree로 미리 만들어둔다고 가정
  for (const f of patch.files) {
    const abs = path.join(sandboxRoot, f.path);
    if (f.action === 'delete') { if (fs.existsSync(abs)) fs.unlinkSync(abs); continue; }
    fs.mkdirSync(path.dirname(abs), { recursive: true });
    fs.writeFileSync(abs, f.content);
  }
  for (const t of patch.tests || []) {
    const abs = path.join(sandboxRoot, t.path);
    fs.mkdirSync(path.dirname(abs), { recursive: true });
    fs.writeFileSync(abs, t.content);
  }
}

function runTests() {
  const sandboxRoot = path.resolve(ROOT, cfg.paths.sandboxDir);
  try {
    const log = execSync('npx vitest run --reporter=basic', { cwd: sandboxRoot, encoding: 'utf8' });
    const m = log.match(/(\d+)\s+passed/);
    return { passed: m ? +m[1] : 0, failed: 0, log };
  } catch (e) {
    const log = (e.stdout || '') + (e.stderr || '');
    const f = log.match(/(\d+)\s+failed/);  const p = log.match(/(\d+)\s+passed/);
    return { passed: p ? +p[1] : 0, failed: f ? +f[1] : 1, log };
  }
}

async function plan(task) {
  const user = `userIntent:\n${task.userIntent}\n\n관련 파일 후보:\n${(task.hintFiles||[]).join('\n')}`;
  const r = await callLLM(cfg.stages.planner, { system: prompts.planner, user });
  const spec = parseJSON(r.text, 'spec');
  if (!validators.spec(spec)) throw new Error('spec schema invalid: ' + ajv.errorsText(validators.spec.errors));
  return { spec, usage: r.usage };
}

async function implement(spec, repoContext, hints = []) {
  const user = JSON.stringify({ spec, repoContext, revisionHints: hints }, null, 2);
  const r = await callLLM(cfg.stages.implementer, { system: prompts.implementer, user });
  const patch = parseJSON(r.text, 'patch');
  if (!validators.patch(patch)) throw new Error('patch schema invalid: ' + ajv.errorsText(validators.patch.errors));
  return { patch, usage: r.usage };
}

async function evaluate(spec, patch, testResult) {
  const user = JSON.stringify({ spec, patch, testResult, weights: cfg.weights }, null, 2);
  const r = await callLLM(cfg.stages.evaluator, { system: prompts.evaluator, user });
  const ev = parseJSON(r.text, 'eval');
  if (!validators.eval(ev)) throw new Error('eval schema invalid: ' + ajv.errorsText(validators.eval.errors));
  return { ev, usage: r.usage };
}

(async () => {
  const taskPath = process.argv[2];
  if (!taskPath) { console.error('usage: node runner.js <task.json>'); process.exit(1); }
  const task = JSON.parse(fs.readFileSync(taskPath, 'utf8'));

  const runId = `${Date.now()}-${task.id || 'task'}`;
  const log = { runId, task, attempts: [], totalUsd: 0 };

  const planned = await plan(task);
  log.spec = planned.spec; log.totalUsd += planned.usage.usd;

  let hints = [];
  for (let attempt = 1; attempt <= cfg.budget.maxRetries + 1; attempt++) {
    const repoContext = loadRepoContext(planned.spec.touchedFiles);
    const impl = await implement(planned.spec, repoContext, hints);
    log.totalUsd += impl.usage.usd;

    try { checkGuardrails(impl.patch); }
    catch (e) { log.attempts.push({ attempt, error: e.message }); break; }

    applyToSandbox(impl.patch);
    const testResult = runTests();

    const evalRes = await evaluate(planned.spec, impl.patch, testResult);
    log.totalUsd += evalRes.usage.usd;
    log.attempts.push({ attempt, patch: impl.patch, testResult, eval: evalRes.ev });

    if (log.totalUsd > cfg.budget.maxUsdPerRun) { console.error('budget exceeded'); break; }
    if (evalRes.ev.verdict === 'approve') { log.finalVerdict = 'approve'; break; }
    if (evalRes.ev.verdict === 'reject')  { log.finalVerdict = 'reject';  break; }
    hints = evalRes.ev.nextActions || [];
  }

  const out = path.resolve(ROOT, cfg.paths.runsDir, `${runId}.json`);
  fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.writeFileSync(out, JSON.stringify(log, null, 2));
  console.log(`done. verdict=${log.finalVerdict || 'incomplete'} usd=${log.totalUsd.toFixed(4)} -> ${out}`);
})();
